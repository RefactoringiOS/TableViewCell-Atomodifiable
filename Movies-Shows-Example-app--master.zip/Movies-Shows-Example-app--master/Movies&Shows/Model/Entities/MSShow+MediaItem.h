//
//  MSShow+MediaItem.h
//  Movies&Shows
//
//  Created by Marcos Sorribas Lopez on 06/07/14.
//  Copyright (c) 2014 Marcos Sorribas. All rights reserved.
//

#import "MSShow.h"
#import "MSMediaItemProtocol.h"

@interface MSShow (MediaItem)<MSMediaItemProtocol>

@end
